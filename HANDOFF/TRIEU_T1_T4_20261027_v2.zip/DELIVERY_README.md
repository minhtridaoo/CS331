# Gói giao việc Triệu T1–T4 — V2, 27/10/2026

**Gói đầu vào và hướng dẫn; chưa phải kết quả Triệu tự chạy/kiểm.** Trí chưa duyệt pilot. Hạn đề xuất: T1 30/10, T2 01/11, T3 02/11, T4 03/11.

## Mở từ đâu

1. Giải nén vào một thư mục riêng, không ghi đè checkout có thay đổi. Thư mục gốc có `evaluation/`, `experiments/`, `results/`, `reports/`.
2. Đọc `reports/KE_HOACH_SUA_KIEM_CHEO_20261027.md` và `HANDOFF/HANDOFF_TRIEU.md`.
3. Kiểm danh sách SHA-256 trong `DELIVERY_MANIFEST.json`. Ghi ngày nhận, máy/OS/Python và hash ZIP Trí gửi. Bản đóng gói đã kiểm CRC và hash; Triệu vẫn kiểm bản mình nhận để phát hiện truyền thiếu/hỏng.
4. T1 chạy Python 3.10+ trong Bash/WSL, tại thư mục gốc gói. Evaluator chỉ dùng thư viện chuẩn; không cần torch, GPU, checkpoint hoặc cài CountGD++ cho T1–T4. Đường dẫn mặc định trong code trỏ theo gốc gói, không theo máy Trí.
5. Làm đúng 7 fixture đầy đủ trong kế hoạch: giữ q05_2 nguyên bản để manual_check không lỗi ngoài mục tiêu; lưu exit code và bằng chứng. Không sửa dữ liệu gốc.

## Những gì đã có

- Code evaluator nguyên trạng, manifest, 15 input, B0 15 dự đoán, hai file B2 6+9, manual q05_2.
- Kết quả tham chiếu 20/10, trace 24/10, review trước và PILOT_SUMMARY. Các bản cũ là bằng chứng có tác giả/ngày cũ, không tự tính là việc Triệu tự làm trong V2.
- 5 ảnh gốc của pilot, gồm mcac_27 cho q05_2/q05_3; overlay q05_2 và gói q05_3 gồm 21 B0, 79 B2, 3 pseudo với CSV còn trắng.
- JSON CV confidence/CLIP và Fusion: 4.6 / 6.8 / 5.8 tương ứng. Đây là điểm dev/CV, chưa là hiệu quả trên ảnh mới.

## Không thuộc gói này

Không có checkpoint, mô hình, toàn bộ dataset, bộ `p4_unseen_v1` DRAFT hoặc runner GPU. Những việc đó thuộc nhánh Trí/P4 và không chặn T1–T4. Các link điều hướng tới tài liệu ngoài phạm vi T1–T4 có thể cần checkout đầy đủ. Link tới chính ZIP trong kế hoạch là đường dẫn trên máy Trí; người nhận đang đọc bản đã giải nén.

## Bàn giao lại

Trả thư mục lượt chạy T1 (fixtures, logs, exit codes, output, CASE_RESULTS); CSV nhãn và minh chứng T2; báo cáo T3 1–2 trang; phần cập nhật PILOT_SUMMARY có bằng chứng thật để hai người duyệt T4. Không đánh dấu các checkbox nhận/chạy/duyệt chỉ vì đã có gói. Không dùng fixture giả để báo hiệu quả CountGD++.

## Nguồn phiên bản

Repo cơ sở HEAD và origin/main: d6db18931c07671763137962f7db54bd1fc3be70. Gói còn chứa các tài liệu/artifact local chưa commit, nên SHA-256 của từng file trong manifest mới là định danh bản được giao. Gói chỉ được tạo local, chưa push hoặc gửi thay Trí.
