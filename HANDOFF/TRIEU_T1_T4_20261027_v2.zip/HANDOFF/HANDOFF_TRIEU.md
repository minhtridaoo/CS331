# Handoff Triệu — thực hiện T1–T4 theo kế hoạch V2

**Cập nhật 27/10/2026.** Nguồn giao việc: [KE_HOACH_SUA_KIEM_CHEO V2](../reports/KE_HOACH_SUA_KIEM_CHEO_20261027.md). [Gói đầu vào ZIP](TRIEU_T1_T4_20261027_v2.zip).

Triệu đã chấp nhận bản kiểm do assistant làm ngày 24/10. **Trí đã đọc và chưa duyệt ngày 27/10**, yêu cầu Triệu tự chạy/kiểm/phân tích. Không ghi việc chấp nhận bản kiểm cũ là đã đáp ứng yêu cầu sửa mới.

| Việc | Hạn đề xuất | Bàn giao |
|---|---|---|
| T0 nhận đủ đầu vào | Trước T1 | Kiểm file/hash/ảnh/Python, ghi ngày nhận |
| T1 tự chạy evaluator + 7 ca | 30/10 | stdout, exit code, output, fixtures, CASE_RESULTS và giải thích tự viết |
| T2 q05_2/q05_3 | 01/11 | Nhãn 21/79/3 dòng + đối chiếu 14 khung q05_2; tổng/uncertain/bỏ sót/minh chứng |
| T3 phân tích từ T2 | 02/11 | Bảng delta, sensitivity q05_3, quan sát/giả thuyết tách rõ và đề xuất |
| T4 duyệt chung | 03/11 | PILOT_SUMMARY có nguồn và người/ngày/quyết định thật |

**T1 đã sửa cách chạy:** mkdir trước redirect; không tạo trước thư mục output của evaluator. Mỗi fixture giữ đủ 15 query, chỉ sửa q01_1, giữ nguyên q05_2 để manual_check không phát sinh lỗi ngoài mục tiêu. Không dùng --skip-manual-review vì code chưa có flag đó. Ca dự kiến bị từ chối cần đúng exit code/lý do, không coi mọi crash là PASS.

**T2:** một nhãn chính/box, có uncertain; không tính part/wrong_class thêm lần nữa vào duplicate. Không cố ép khớp nhãn cũ khi có bằng chứng khác. **T3:** B2 confidence=4.6, CLIP-only=6.8, Fusion=5.8; tổng lỗi +39 nhưng q05_3 riêng +58, phần còn lại −19. Phải viết phân tích của mình, không chép mốc tham chiếu như việc tự làm.

Những mốc này là đề xuất, chưa có xác nhận nhận việc. ZIP mới chuẩn bị tại máy Trí, chưa được assistant gửi; các gói vẫn chưa nằm trên origin/main d6db189. T1–T4 không cần tập P4_unseen hoặc GPU.

47 nhãn q03 là việc P4 riêng, không cộng vào điều kiện đóng pilot T1–T4. Trí tiếp tục kiểm dữ liệu và runner song song. Không yêu cầu ablation/đổi model/train trong vòng sửa này; chưa biết cơ chế nội tại được ghi như giới hạn.
