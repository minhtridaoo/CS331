# CS331 — mở file này khi bắt đầu làm

**Cập nhật tài liệu: 19/10/2026.** Kết quả thực nghiệm gần nhất đã kiểm: 16/10. Việc sắp xếp ngày 19/10 không phải một lần chạy model/evaluator mới.

| Bạn muốn làm gì? | File cần mở |
|---|---|
| Ghi hôm nay làm gì, lỗi gì, bước tiếp | [WORKLOG.md](WORKLOG.md) — nhật ký chính duy nhất |
| Xem đang ở đâu và điều kiện hoàn thành | [Roadmap](roadmap/ROADMAP.md) |
| Tiếp tục ngay từ lần trước | [Handoff hiện hành](HANDOFF/HANDOFF.md) |
| Phần 2: tự chạy bộ đánh giá | [Hướng dẫn phần 2](roadmap/PHAN_2_DANH_GIA.md) |
| Phần 3: hoàn thiện tổng kết pilot | [Hướng dẫn phần 3](roadmap/PHAN_3_TONG_KET.md) |
| Điền bản tổng kết | [PILOT_SUMMARY.md](reports/PILOT_SUMMARY.md) |
| Đánh giá cấu hình paper trên Kaggle | [Kaggle](roadmap/KAGGLE_PAPER_EVAL.md) |
| Tra cứu tài liệu cũ | [Kho quá khứ](<quá khứ/2026-10-19/README.md>) |

Phần 2–3 ở đây là đánh giá **pilot 5 ảnh / 15 query**, không phải benchmark FSCD-147, cũng không phải E2/E3 về ngưỡng. Không cần chạy lại B0/B2 để tính chỉ số từ file đã lưu.

Cuối mỗi buổi: cập nhật một dòng ở WORKLOG, trạng thái tương ứng trong ROADMAP và dòng “Việc tiếp theo” trong HANDOFF. Chỉ đánh dấu xong khi có đường dẫn bằng chứng. Người dùng tự chạy; assistant muốn chạy đánh giá/thực nghiệm thay phải hỏi trước theo yêu cầu ngày 19/10.
