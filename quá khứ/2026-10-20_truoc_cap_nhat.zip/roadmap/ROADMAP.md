# Roadmap CS331 — CountGD++ và lỗi đếm sai đối tượng

**Phiên bản tài liệu V4.4, cập nhật 19/10/2026.** Trạng thái thực nghiệm dựa trên bằng chứng đến 16/10; hôm nay chỉ tổ chức tài liệu và chuẩn bị công cụ tự chạy.

[Trang bắt đầu](../README.md) · [Work log chính](../WORKLOG.md) · [Handoff](../HANDOFF/HANDOFF.md)

## Mục tiêu và phạm vi

Cùng một ảnh có X và Y khác loại: khi hỏi X/Y, mô hình phải đếm đúng loại được hỏi. CountGD++ là baseline; B0 là text một lượt, B2 là text → tối đa 3 mẫu tự chọn → lượt hai. Hai cấu hình qua app là đối chứng thành phần, không đại diện toàn pipeline đạt điểm paper. Zero-shot không có nghĩa checkpoint chưa từng được train.

Ưu tiên chẩn đoán sai loại; trùng khung, phần vật và bỏ sót được ghi riêng. Không train, đổi model hoặc chọn module trước khi có giả thuyết và phép đo. Nhãn thật chỉ cho evaluator, không làm đầu vào model.

## Bảng tiến độ — bạn cập nhật trực tiếp ở đây

| Việc | Trạng thái ngày 19/10 | Bằng chứng / điều kiện xong |
|---|---|---|
| M0–M2: môi trường, model, checkpoint | Chạy được, đã audit | Model/extension chạy; còn benchmark tài nguyên chuẩn nếu cần báo hiệu năng |
| M3: smoke 1 ảnh / 3 query | Đã chạy và xem ảnh | [Lịch sử](../WORKLOG.md) |
| M4–M5: B0/B2 5 ảnh / 15 query | Đã chạy đủ | [Bảng số liệu](../results/countgdpp/b2_remaining3_20261015/REVIEW.md) |
| M6: E1/E2 | Đã đóng pilot 2 ảnh / 6 query | E2 .35 không chạy; E3 chưa cần mở chỉ để đủ lưới |
| Review Trí / Triệu | Trí 15/15, Triệu 14/15 | [Đối chiếu](../results/countgdpp/b2_remaining3_20261015/TRIEU_CROSSCHECK_2026-10-16.md); còn guitar/q04_2 |
| **Phần 2: evaluator pilot** | **Đã chuẩn bị code; chưa chạy self-test/dữ liệu** | [Hướng dẫn](PHAN_2_DANH_GIA.md); self-test đạt + metrics/coverage + manual_check |
| **Phần 3: tổng kết pilot** | **Có bản nháp từ bằng chứng cũ; chờ phần 2** | [Hướng dẫn](PHAN_3_TONG_KET.md); điền nguồn run, kiểm kết quả, ký xác nhận phạm vi |
| P4: chọn một can thiệp | Chưa chốt | Một giả thuyết, một ứng viên, đối chứng và cách đo được thống nhất |
| Benchmark paper trên Kaggle | Có notebook; chưa có kết quả xác nhận | [Hướng dẫn](KAGGLE_PAPER_EVAL.md); bắt đầu cell 1–2 |
| P5: đánh giá cải tiến/holdout và báo cáo | Chưa làm | Khóa cấu hình, chạy tập riêng, báo chỉ số/case/giới hạn |

Trạng thái dùng: Chưa làm / Đang làm / Đã chuẩn bị / Chờ kiểm / Đã xác nhận. “Có code” không đồng nghĩa “đã chạy đạt”.

## Điều kiện đóng vòng pilot hiện tại

- [ ] Triệu bổ sung guitar và làm rõ q04_2; nếu chưa giải quyết được thì ghi rõ chưa chắc và không dùng khẳng định “toàn bộ” làm số liệu định lượng.
- [ ] Phần 2: self-test đạt; đủ 15 ID chung, báo errors/uncertain; MAE/RMSE khớp kết quả cũ trong sai số làm tròn; q05_2 tổng hợp 4 vật + 1 dư trùng + 9 sai loại.
- [ ] Phần 3: điền và duyệt PILOT_SUMMARY, phân biệt số liệu máy, review bằng mắt và giả thuyết. Chưa tuyên bố đã tìm ra cơ chế hay phương pháp mới.

Đóng pilot không đồng nghĩa hoàn thành toàn bộ M4/P1/P3 theo phạm vi lớn. Kế hoạch 20–30 ảnh dev, truy vấn chắc chắn vắng mặt, holdout theo ảnh gốc, nguồn/giấy phép dữ liệu, evaluator định vị và tài nguyên vẫn phải giải quyết trước các tuyên bố đánh giá rộng/cải tiến. Không cần tự đếm lại mọi ảnh của benchmark nếu đã có annotation và evaluator đáng tin.

## Kết quả đang có

Trên cùng 15 query: B0 MAE=19.4, RMSE≈24.316; B2 MAE=22.0, RMSE≈30.091; exact count 1/15 cả hai. B2 giảm sai số 6, tăng 4, giữ nguyên 5 query. Plates/rulers/raspberries có mẫu đúng loại 3/3 nhưng final vẫn sai/thừa; blackberries có khung theo phần quả. Chưa khái quát từ 5 ảnh ra mọi cấu hình CountGD++.

Kaggle FSCD-147 là nhánh kiểm cấu hình paper đã được yêu cầu trước đó: không so MAE trực tiếp với pilot khác tập, không chỉnh tham số theo test để khớp điểm paper.

## Cách cập nhật

1. Bạn chạy theo hướng dẫn phần 2 hoặc tự hoàn thiện phần 3.
2. Ghi lệnh/run, kết quả, lỗi và bước tiếp vào [WORKLOG](../WORKLOG.md).
3. Sửa đúng dòng trạng thái và ô checklist có bằng chứng; cập nhật handoff.
4. Chỉ tạo bản lưu mới trong “quá khứ” khi đổi cấu trúc/phiên bản lớn. Không tạo thêm handoff theo ngày ở thư mục hiện hành.

[Protocol kỹ thuật](PIPELINE_COUNTGDPP.md) · [Phân công/schema](PIPELINE_PHAN_CONG.md) · [Roadmap trước chỉnh sửa](<../quá khứ/2026-10-19/roadmap/CS331_ZSC_V4_Final.md>)
