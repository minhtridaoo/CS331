# Phần 3 — tự hoàn thiện báo cáo pilot

**File bạn sửa: [reports/PILOT_SUMMARY.md](../reports/PILOT_SUMMARY.md).** Đã điền bằng chứng cũ để bạn không phải chép lại, nhưng trạng thái vẫn là bản nháp. Phần này không có lệnh train/inference cần chạy.

## Trình tự làm

1. Hoàn tất phần 2. Mở `SUMMARY.md`, `metrics.json`, `manual_check.json` trong output evaluator do bạn vừa tạo.
2. Điền đường dẫn run mới, ngày chạy, người chạy và kết quả self-test trong PILOT_SUMMARY. Đối chiếu bảng số liệu đã điền từ run cũ; chỉ xác nhận sau khi run mới khớp, không ghi là đã xác nhận ngay.
3. Cùng Triệu cập nhật review guitar và q04_2; nếu chưa chắc, giữ nhãn chưa rõ và bỏ khẳng định định lượng không có bằng chứng. Review đó không chặn việc chạy evaluator count phần 2 bằng GT hiện có, nhưng phải công bố giới hạn nhãn.
4. Kiểm ba kiểu lỗi có ví dụ: sai loại dù mẫu đúng, trùng/phần vật, bỏ sót lớp có mặt. Không biến mọi “đếm thừa” thành “đếm trùng”.
5. Chọn một câu hỏi can thiệp để thảo luận: giảm giữ khung sai loại mà không bỏ vật đúng. Ghi một ứng viên và đối chứng sau khi nghiên cứu; nếu chưa chọn được thì để “chưa chốt”, không gọi phương pháp mới.
6. Điền quyết định ở cuối báo cáo: pilot đã đủ ghi nhận lỗi và chuyển P4, hay còn một mục cụ thể cần sửa. Ghi WORKLOG và cập nhật ROADMAP/HANDOFF.

## Kiểm tra trước khi chốt

- [ ] Phạm vi rõ 5 ảnh/15 query dev; E1/E2 chỉ 2 ảnh/6 query.
- [ ] B0/B2 cùng tập IDs và có coverage; có đường dẫn output evaluator thực tế.
- [ ] Mọi số liệu mới có nguồn; các số đã có trước ngày 19/10 được ghi đúng nguồn lịch sử.
- [ ] Triệu review 14/15, còn guitar và q04_2 được cập nhật hoặc ghi rõ giới hạn; q05_2 không cần gán nhãn lại từ đầu.
- [ ] Không so MAE pilot với điểm FSCD-147 khác tập; không gọi B2 adapter là đầy đủ paper.
- [ ] Không nhận đã thử E3/train/cải tiến/holdout, chưa có bằng chứng cho các việc này.
- [ ] Có một bước P4 cụ thể, người phụ trách và cách đo trước khi mở holdout.

## Khi nào phần 3 xong?

Khi PILOT_SUMMARY được bạn duyệt, kết quả phần 2 đã xác nhận và các điểm chưa chắc được xử lý minh bạch. Được phép kết luận “có vấn đề cần khảo sát, chưa có phương pháp cải tiến đã chứng minh”. Đóng pilot không đồng nghĩa hoàn thành benchmark Kaggle, evaluator định vị toàn tập hoặc toàn bộ đồ án.

[Quay lại phần 2](PHAN_2_DANH_GIA.md) · [Work log](../WORKLOG.md) · [Roadmap](ROADMAP.md)
