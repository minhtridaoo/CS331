# Handoff Triệu — dữ liệu và đánh giá

Cập nhật 19/10/2026. [Trạng thái chung](HANDOFF.md) · [Work log](../WORKLOG.md)

Đã cung cấp gói dữ liệu và review 14/15 query. Còn q01_1 guitars chưa review trực tiếp; q04_2 cần đối sánh 32 khung với mô tả độ bao phủ. Q05_2 final đã giải thích đủ 14 khung, không gán nhãn lại từ đầu. [Đối chiếu](../results/countgdpp/b2_remaining3_20261015/TRIEU_CROSSCHECK_2026-10-16.md).

Phần 2 là công việc evaluator của nhánh này, có thể cùng Trí chạy CPU: [hướng dẫn](../roadmap/PHAN_2_DANH_GIA.md), [code mới chuẩn bị](../evaluation/evaluate_pilot.py). Đây chưa phải code đã được Triệu kiểm/đánh giá chạy. Đọc schema, kiểm fixture trước, chấm đủ IDs và báo coverage/errors/absent=null đúng nghĩa. Manual check chỉ đếm nhãn hậu kiểm, không tự phân loại bbox bằng model.

Cùng Trí hoàn thiện [báo cáo pilot](../reports/PILOT_SUMMARY.md). Dữ liệu nguồn, truy vấn absent có xác minh, split dev/holdout và evaluator định vị rộng hơn vẫn còn trong kế hoạch. Không coi review bằng mắt là hoàn thành tất cả các mục này.

Nhật ký chung ở WORKLOG gốc; trạng thái chỉ đánh dấu khi có bằng chứng. File này là phân công, không xác nhận đã gửi việc hoặc Triệu đã làm mục chưa có output.
