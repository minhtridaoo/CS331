# Tổng kết pilot CS331 — CountGD++ và lỗi chọn đối tượng

**BẢN NHÁP cập nhật 19/10/2026.** Nội dung dưới đây dùng bằng chứng đã kiểm đến 16/10. Evaluator mới ngày 19/10 chưa chạy; chưa coi báo cáo được nhóm duyệt.

## 1. Thông tin bạn tự điền

- Người chạy evaluator: **[CHƯA ĐIỀN]**
- Ngày chạy: **[CHƯA ĐIỀN]**
- Self-test: **[CHƯA CHẠY / PASS / FAIL + log]**
- Thư mục evaluator thực tế: **[CHƯA CÓ OUTPUT]**
- Coverage/IDs đã kiểm: **[CHƯA XÁC NHẬN]**
- Người kiểm chéo/ngày: **[CHƯA XÁC NHẬN]**
- Trạng thái báo cáo: **NHÁP / CHỜ KIỂM / ĐÃ CHỐT PILOT**

## 2. Câu hỏi và thiết lập

Cùng ảnh, đổi tên loại X/Y có làm mô hình đếm riêng đúng loại được hỏi không? Dùng checkpoint CountGD++, chưa fine-tune. B0 là text một lượt; B2 là lượt đầu → top tối đa 3 mẫu tự chọn → lượt hai. Tau_sample=tau_final=.23; không mẫu thì trả B0 theo quy ước adapter. Đây không phải tái hiện toàn pipeline paper.

Tập 5 ảnh/15 query dev từ gói dữ liệu Triệu; mọi query trong tập này có đối tượng. GT chỉ đưa vào evaluator. Không có holdout độc lập hoặc absent query trong 15 dòng. Mẫu và khung được review bằng mắt để chẩn đoán, không dùng nhãn hậu kiểm làm input model.

## 3. Kết quả đã có trước evaluator mới

Nguồn: [combined_first5_metrics.json](../results/countgdpp/b2_remaining3_20261015/combined_first5_metrics.json). **Chờ đối chiếu bằng output phần 2.**

| Cấu hình | Số query | MAE | RMSE | Đúng count |
|---|---:|---:|---:|---:|
| B0 | 15 | 19.4 | 24.315976 | 1/15 |
| B2 | 15 | 22.0 | 30.090973 | 1/15 |

B2 giảm sai số 6 query, tăng 4, giữ nguyên 5. Đếm giảm chưa chứng minh đúng loại; B2 không cải thiện MAE trung bình trên pilot này. Không loại ca blackberries để làm kết quả đẹp hơn.

**Xác nhận sau phần 2:** [điền run, coverage/errors/uncertain và có khớp bảng hay không; nếu lệch ghi nguyên nhân].

## 4. Bằng chứng định tính và kiểm chéo

- Trí review 15/15 query; Triệu 14/15, còn guitar chưa có review trực tiếp trong bản hiện có.
- Plates hiệu chỉnh 0/3 theo nhận xét Trí ban đầu thành 3/3 đúng loại theo Triệu và ảnh kiểm. Bản gốc giữ nguyên. Tổng 23/42 mẫu đúng là tổng hợp hỗn hợp nguồn, không phải 42 mẫu đều đã có hai người xác nhận.
- Plates/rulers/raspberries có 3/3 mẫu đúng loại nhưng final vẫn sai/thừa: chọn đúng mẫu chưa bảo đảm kết quả đúng trong cấu hình này.
- Raspberries final: 14 = 4 quả mục tiêu + 1 khung trùng + 9 khung sai loại. Đây là nhãn bằng mắt/tọa độ, chưa phải IoU/AP/precision/recall chuẩn.
- Blackberries 21→79: vừa đếm phần quả, vừa lẫn loại; chưa phân loại đủ 79 khung để lượng hóa mọi cơ chế.
- Chairs có GT=1 nhưng trả 0, là bỏ sót lớp có mặt; không phải ca absent.

[Đối chiếu Triệu](../results/countgdpp/b2_remaining3_20261015/TRIEU_CROSSCHECK_2026-10-16.md) · [Nhãn q05_2](../results/countgdpp/b2_remaining3_20261015/q05_2/manual_crosscheck_20261016.json)

**Guitar và q04_2 sau kiểm bổ sung:** [CHƯA CẬP NHẬT]. Nếu q04_2 chưa đối sánh từng vật, không viết đã phát hiện “toàn bộ” 24 blueberries + 10 blackberries + 1 red currant vì không khớp 32 bbox.

## 5. Đối chứng ngưỡng và giới hạn

E1 thay ngưỡng cuối với mẫu cố định; E2 thay ngưỡng mẫu giữ cuối=.23, chỉ trên 2 ảnh/6 query. E2 chạy .10/.23/.50; .35 bỏ qua có lý do từ điểm top-3, không báo là đã chạy. Chưa E3, train hoặc cải tiến mới. [E1](../results/countgdpp/m6_e1_final_20261015/REVIEW.md) · [E2](../results/countgdpp/m6_e2_sample050_20261015/REVIEW.md).

5 ảnh chưa đại diện toàn benchmark. Nhãn đếm có từ gói nguồn nhưng xuất xứ/giấy phép và toàn bộ định vị chưa được xác minh đầy đủ. Chưa có absent/holdout; benchmark tài nguyên chuẩn và Kaggle chưa được xác nhận. Chưa tìm ra nguyên nhân nội tại kiến trúc từ các quan sát này.

## 6. Quyết định sang P4 — bạn và Triệu điền

- Lỗi ưu tiên: **đếm nhầm loại khi đổi query X/Y**, kể cả khi mẫu tự chọn đúng loại.
- Giả thuyết cụ thể sẽ thử: **[CHƯA CHỐT]**.
- Một phương pháp ứng viên và tài liệu nguồn: **[CHƯA CHỐT]**.
- Baseline/đối chứng giữ nguyên: **[điền cấu hình B0/B2 nào, cùng dữ liệu]**.
- Cách đo giữ vật đúng và loại vật sai: **[định nghĩa/matching trước khi chạy; không chỉ MAE]**.
- Dev dùng chọn cấu hình và holdout riêng: **[CHƯA CHỐT]**.
- Quyết định: **[đóng vòng pilot / còn mục ...]**; người duyệt/ngày: **[...]**.

Không cần tuyên bố có phương pháp mới để đóng báo cáo pilot. Khi đã điền, cập nhật [WORKLOG](../WORKLOG.md), [ROADMAP](../roadmap/ROADMAP.md), [HANDOFF](../HANDOFF/HANDOFF.md).
