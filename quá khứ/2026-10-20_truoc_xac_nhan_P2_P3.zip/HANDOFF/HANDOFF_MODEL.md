# Handoff Trí — mô hình và thí nghiệm

Cập nhật 20/10/2026. [Trạng thái chung](HANDOFF.md) · [Work log](../WORKLOG.md)

Đã có model/checkpoint chạy, B0/B2 5 ảnh/15 query và E1/E2 pilot 2 ảnh. Phần chạy và review nhỏ đã có bằng chứng; không cần rerun inference để tính metric.

Việc hiện tại: đọc và tự chạy [phần 2](../roadmap/PHAN_2_DANH_GIA.md) cùng Triệu; kiểm self-test, metric/coverage và nhãn q05_2. Ghi run thật rồi điền [phần 3](../roadmap/PHAN_3_TONG_KET.md). Chưa chạy evaluator mới, chưa đóng báo cáo.

Kaggle đã chạy đủ 1.190 ảnh; kiểm ngày 20/10: MAE=8.336975, RMSE=24.637626. [Báo cáo benchmark](../reports/BENCHMARK_FSCD147.md). Không cần chạy lại nhánh này để làm phần 2–3 pilot. Chưa train/cải tiến/holdout. Đo thời gian/VRAM chuẩn còn cần làm trước khi báo hiệu năng.

Mỗi buổi thêm mục WORKLOG; khi xong mốc mới đồng bộ trạng thái ROADMAP và việc tiếp HANDOFF. Assistant chạy đánh giá/thực nghiệm thay phải hỏi bạn trước.
