# Handoff Triệu — dữ liệu và đánh giá

Cập nhật 20/10/2026. [Trạng thái chung](HANDOFF.md) · [Work log](../WORKLOG.md)

Đã cung cấp gói dữ liệu và **chốt review định tính 15/15 query v1 ngày 19/10**, được đọc lại ngày 20/10. Guitar được xác nhận đúng theo quy ước review của Triệu; q04_2 final đã giải thích đủ 32 khung. Q05_2 final cũng đủ 14 khung; không cần review lại các ca này từ đầu. [Bản chốt hiện tại](<../workspace Trí and Triệu/Triệu/TRIEU_VISUAL_REVIEW.md>).

Bản review có liên kết `Q02_1_DETAILED_REVIEW.md`, nhưng chưa tìm thấy file đó trong workspace. Nếu báo cáo dùng bảng ghép chi tiết q02_1, cần bổ sung artifact; hiện chỉ ghi kết luận định tính và độ chắc chắn như trong bản chốt, không nhận mọi box đã được Triệu xác nhận.

Phần 2 là công việc evaluator của nhánh này, có thể cùng Trí chạy CPU: [hướng dẫn](../roadmap/PHAN_2_DANH_GIA.md), [code mới chuẩn bị](../evaluation/evaluate_pilot.py). Đây chưa phải code đã được Triệu kiểm/đánh giá chạy. Đọc schema, kiểm fixture trước, chấm đủ IDs và báo coverage/errors/absent=null đúng nghĩa. Manual check chỉ đếm nhãn hậu kiểm, không tự phân loại bbox bằng model.

Cùng Trí hoàn thiện [báo cáo pilot](../reports/PILOT_SUMMARY.md). Dữ liệu nguồn, truy vấn absent có xác minh, split dev/holdout và evaluator định vị rộng hơn vẫn còn trong kế hoạch. Không coi review bằng mắt là hoàn thành tất cả các mục này.

Benchmark của Trí đã chạy đủ 1.190 ảnh và có [báo cáo xác nhận count metrics](../reports/BENCHMARK_FSCD147.md). Phần này không thay kiểm chéo dữ liệu/evaluator của pilot.

Nhật ký chung ở WORKLOG gốc; trạng thái chỉ đánh dấu khi có bằng chứng. File này là phân công, không xác nhận đã gửi việc hoặc Triệu đã làm mục chưa có output.
