# Handoff CS331 — tiếp tục từ đây

**Cập nhật 20/10/2026.** [Trang bắt đầu](../README.md) · [Tiến độ chính](../roadmap/ROADMAP.md) · [Nhật ký](../WORKLOG.md).

## Đã xác nhận

- **Pilot** là bộ thử 5 ảnh / 15 câu hỏi để tìm lỗi đếm sai đối tượng. B0/B2 đã chạy đủ; Trí và Triệu đều review định tính 15/15; bản Triệu chốt v1 ngày 19/10 đã được đọc lại ngày 20/10. E1/E2 đã khảo sát trên 2 ảnh / 6 câu hỏi.
- B0 MAE=19.4; B2 MAE=22.0. q05_2 final đã có nhãn: 14 khung = 4 quả mục tiêu + 1 trùng + 9 sai loại. Plates hiệu chỉnh thành mẫu đúng loại 3/3. Guitar đã xác nhận đúng theo quy ước review của Triệu; q04_2 đã giải thích 32 khung = 24 blueberry + 7 blackberry + 1 red currant. [Review hiện tại](<../workspace Trí and Triệu/Triệu/TRIEU_VISUAL_REVIEW.md>).
- **Benchmark FSCD-147 đã chạy đủ 1.190 ảnh.** Log và metrics khớp MAE=8.336975, RMSE=24.637626; danh sách ảnh và GT đếm đã đối chiếu ngày 20/10. [Báo cáo và bằng chứng](../reports/BENCHMARK_FSCD147.md).
- Run benchmark mang ngày 15/10 theo log; ngày 20/10 là ngày kiểm tại workspace. File run_config ở gốc gói còn `prepared_not_run`; dùng bản trong thư mục `full_20261015T080230Z` cùng log để xác định trạng thái run.

## Việc ngay tiếp — làm đúng thứ tự

1. **Trí — phần 2:** mở [hướng dẫn](../roadmap/PHAN_2_DANH_GIA.md), chạy `python evaluation/evaluate_pilot.py --self-test`. PASS mới chạy output `results/countgdpp/pilot_eval_20261020`. Chưa có output evaluator này trong workspace khi kiểm ngày 20/10. Không cần chạy lại B0/B2.
2. **Triệu — kiểm chéo evaluator:** đọc code/schema, kiểm một vài dòng ID/GT/prediction và kết quả q05_2 sau phần 2. Review định tính 15/15 đã chốt, không giao lại guitar/q04_2. Bản review dẫn tới `Q02_1_DETAILED_REVIEW.md` nhưng file đó chưa có trong gói local; bổ sung khi cần dùng bảng ghép chi tiết q02_1, không chặn chạy count evaluator.
3. **Trí + Triệu — phần 3:** theo [hướng dẫn](../roadmap/PHAN_3_TONG_KET.md), hoàn thiện [PILOT_SUMMARY](../reports/PILOT_SUMMARY.md) từ output thật. Đây vẫn là bản nháp.
4. Khi chốt pilot, thống nhất một giả thuyết cải tiến, cấu hình nền và phép đo. Chưa có phương pháp cải tiến được kiểm chứng; holdout/cải tiến/báo cáo cuối còn phía sau.

“Phần 2–3” là chấm và tổng kết pilot, không phải E2/E3 hoặc cell 2/3 notebook Kaggle. Nhánh Kaggle đã có kết quả; không bắt đầu lại cell 1–2 chỉ để tiếp tục công việc hiện tại.

## Trạng thái để buổi sau tiếp tục

- Đang ở: **cuối vòng baseline/pilot đầu tiên**.
- Evaluator pilot mới: **đã chuẩn bị, chưa xác nhận chạy**.
- Báo cáo pilot: **NHÁP**.
- Benchmark paper: **count metrics đã kiểm; chưa xác nhận AP/AP50 hoặc tái lập mọi chi tiết môi trường/code**.
- Việc tiếp theo: **Trí tự chạy self-test phần 2**.

Mỗi buổi ghi WORKLOG; khi xong mốc cập nhật ROADMAP và handoff này. Lịch sử có tại [quá khứ](<../quá khứ/README.md>); không dùng trạng thái trong bản cũ thay cho trạng thái hiện hành.

Theo yêu cầu người dùng ngày 19/10, assistant muốn chạy self-test/evaluator/inference/train thay phải hỏi trước. Kiểm file kết quả đã được gửi, tổ chức workspace và cập nhật tài liệu đã được yêu cầu trong lượt 20/10. Lượt này chỉ audit artifact benchmark và sửa tài liệu, không chạy evaluator pilot hoặc model mới.

[Phần Trí](HANDOFF_MODEL.md) · [Phần Triệu](HANDOFF_TRIEU.md) · [Protocol](../roadmap/PIPELINE_COUNTGDPP.md) · [Phân công/schema](../roadmap/PIPELINE_PHAN_CONG.md).
