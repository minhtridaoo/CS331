# Phần 2 — tự chạy evaluator trên kết quả đã lưu

**Chuẩn bị ngày 19/10; kiểm trạng thái ngày 20/10/2026: chưa thấy output self-test/đánh giá thật của chương trình này trong workspace.** Mã được kiểm cú pháp; kết quả đúng phải do lần chạy của bạn xác nhận.

Đây là **phần 2: kiểm số liệu pilot 5 ảnh/15 câu hỏi**. Benchmark Kaggle 1.190 ảnh đã chạy xong và có [báo cáo riêng](../reports/BENCHMARK_FSCD147.md); nó không thay thế việc ghép/chấm các câu hỏi pilot. Phần này cũng không phải thí nghiệm **E2** đổi ngưỡng chọn mẫu.

## File nào làm việc gì?

| Nội dung | File |
|---|---|
| Bạn đọc/sửa code evaluator | [evaluation/evaluate_pilot.py](../evaluation/evaluate_pilot.py) |
| Đánh dấu trạng thái | [ROADMAP](ROADMAP.md), dòng Phần 2 |
| Ghi lệnh và kết quả mỗi lần chạy | [WORKLOG](../WORKLOG.md) |
| Nhãn GT | [manifest](../experiments/countgdpp/m4_inputs/manifest.csv) — chỉ đọc để chấm |
| Tập 15 query cần chấm | [first5_inputs](../experiments/countgdpp/m4_inputs/first5_inputs.jsonl) |
| Số liệu tham chiếu đã có | [combined_first5_metrics.json](../results/countgdpp/b2_remaining3_20261015/combined_first5_metrics.json) |
| Nhãn hậu kiểm raspberries | [manual_crosscheck](../results/countgdpp/b2_remaining3_20261015/q05_2/manual_crosscheck_20261016.json) |

Đây là script mới, chưa phải sản phẩm evaluator được Triệu xác nhận. Bạn có thể dùng để đọc hiểu/chạy và Triệu kiểm chéo, hoặc cùng Triệu hoàn thiện triển khai riêng theo cùng schema. Không chạy hai triển khai rồi chọn số nào đẹp hơn.

## 2A. Đọc luồng code

`read_jsonl/indexed` đọc và kiểm ID → `validate_prediction` kiểm count/boxes/scores → `evaluate` ghép GT và tính chỉ số → `manual_check` đếm lại nhãn khung đã có → `main` lưu outputs.

- Chỉ lấy 15 query trong first5_inputs, dù manifest có 30 query; B2 ghép hai run 6+9 query, không cộng trùng.
- GT chỉ được đọc sau inference. Không thay predictions hoặc GT để ép khớp số tham chiếu.
- ID thiếu/thừa/trùng, count khác số khung gây dừng. Error/null được báo riêng; không đổi thành count 0.
- Chỉ so B0/B2 trên cùng query hợp lệ, báo cả coverage từng bên. Query uncertain không coi là absent.
- Bộ hiện tại chỉ có query present: FPR_absent và MeanAbsentCount phải là null. Đây không phải bằng chứng không có lỗi absent.
- Manual check chỉ đếm nhãn người đã gán, không tự nhận diện bbox đúng/sai từ ảnh hoặc tính IoU/AP.

## 2B. Chạy kiểm thử dữ liệu giả trước

Trong Ubuntu, copy:

```bash
source /root/.venvs/countgdpp/bin/activate
cd /mnt/d/MINHTRIHOCCODE/HOCKI5/CS331
python evaluation/evaluate_pilot.py --self-test
```

Đầu ra mong đợi bắt đầu bằng `SELF-TEST PASS`. Fixture gồm lỗi đếm biết đáp án, ID trùng/thiếu, count không khớp khung, error/null. Không tải model, không cần GPU. Nếu lỗi: ghi log vào WORKLOG và sửa code/input trước khi đi tiếp; chưa đánh dấu đạt.

## 2C. Tính lại số liệu thật

Chỉ chạy khi 2B đạt:

```bash
python evaluation/evaluate_pilot.py --out results/countgdpp/pilot_eval_20261020
```

Mặc định đọc B0 `m4_first5_b0`, B2 `b2_two_images_20261015` + `b2_remaining3_20261015`, manifest/inputs và nhãn q05_2 ở trên. Khi chạy lại, dùng tên mới, ví dụ `pilot_eval_20261020_r2`; chương trình không ghi đè thư mục cũ.

Sản phẩm trong thư mục output mới (chưa tồn tại trước khi bạn chạy):

- `metrics.json`: metric từng bên, metric trên tập chung, coverage/errors/uncertain.
- `per_query.json`: 15 dòng ghép GT/B0/B2 và sai số, dùng đối chiếu ID.
- `manual_check.json`: phép đếm nhãn q05_2.
- `run_config.json`: lệnh và SHA256 các file nguồn/code.
- `SUMMARY.md`: bảng đọc nhanh, không thay thế phần 3.

## 2D. Đối chiếu để được đánh dấu xong

| Kiểm tra | Giá trị mong đợi trên dữ liệu hiện tại |
|---|---|
| expected_queries / expected_images | 15 / 5 |
| coverage B0 và B2 | 15 hợp lệ, 0 error mỗi bên; 0 uncertain |
| paired.n_queries | 15 |
| B0 MAE / RMSE | 19.4 / khoảng 24.315976 |
| B2 MAE / RMSE | 22.0 / khoảng 30.090973 |
| exact_count | 1 cho mỗi bên |
| improved / worsened / unchanged | 6 / 4 / 5 |
| n_absent | 0; các metric absent null |
| manual final_boxes / target_boxes | 14 / 5 |
| manual distinct_target_objects / extra_target_boxes / wrong_class_boxes | 4 / 1 / 9 |

Chấp nhận khác biệt làm tròn số thực; không chấp nhận khác IDs/coverage. Nếu dữ liệu nguồn thay đổi hợp lệ, ghi phiên bản và giải thích, không tự ép metric theo bảng. Nhãn manual có lỗi phần vật giao với sai loại/trùng, không cộng trùng các nhóm lỗi.

## Kết thúc phần 2

- [ ] Self-test thực sự chạy PASS; ghi ngày/lệnh vào WORKLOG.
- [ ] Output thật có 5 file, kiểm các giá trị trên; ghi run thực tế.
- [ ] Triệu đọc code/schema và kiểm một vài dòng ghép, q05_2; ghi người/ngày xác nhận, không tự gán Triệu đã làm.
- [ ] Sửa trạng thái ROADMAP/HANDOFF rồi chuyển [Phần 3](PHAN_3_TONG_KET.md).

Assistant chưa chạy các lệnh trên. Nếu muốn assistant chạy thay, bạn phải đồng ý trước theo yêu cầu của bạn ngày 19/10.
