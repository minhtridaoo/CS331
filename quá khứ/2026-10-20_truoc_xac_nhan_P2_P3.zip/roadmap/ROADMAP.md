# Roadmap CS331 — CountGD++ và lỗi đếm sai đối tượng

**V4.5 — cập nhật 20/10/2026.** Đây là bảng tiến độ chính. [Trang bắt đầu](../README.md) · [Nhật ký](../WORKLOG.md) · [Handoff](../HANDOFF/HANDOFF.md).

## Nhìn toàn bộ đồ án trong bốn chặng

| Chặng | Kết quả cần có | Trạng thái thực tế |
|---|---|---|
| 1. Chạy được baseline | Môi trường, checkpoint, inference và nhánh kiểm trên tập chuẩn | **Đã có.** Benchmark FSCD-147 1.190 ảnh đã kiểm count metrics ngày 20/10. |
| **2. Hiểu và đo lỗi X/Y** | Bộ thử nhỏ, review, evaluator, báo cáo lỗi | **ĐANG Ở ĐÂY.** Đã chạy pilot; còn chốt phần 2–3 bên dưới. |
| 3. Thử một cải tiến | Một giả thuyết có lý do, phương pháp, đối chứng trên cùng dữ liệu | **Chưa chốt phương pháp, chưa triển khai.** |
| 4. Đánh giá và báo cáo cuối | Cấu hình khóa trước đánh giá, tập riêng, bảng so sánh, ví dụ và giới hạn | **Chưa hoàn thành.** |

Bạn gần xong vòng kiểm baseline/pilot đầu tiên, chưa gần xong toàn bộ đồ án. Không gán phần trăm vì phạm vi cải tiến chưa chốt.

## Pilot và benchmark là hai nhánh khác nhau

**Pilot = bộ thử nhỏ để tìm lỗi:** 5 ảnh, 15 câu hỏi. Cùng ảnh hỏi những loại khác nhau để quan sát khung dự đoán. B0 là văn bản một lượt; B2 là lượt đầu → tối đa 3 mẫu tự chọn → lượt hai. Đây là đối chứng thành phần qua adapter.

**Benchmark = phép kiểm trên tập chuẩn:** FSCD-147 test, 1.190 ảnh, cấu hình text + synthetic + pseudo + adaptive cropping. Đã chạy đủ, số liệu MAE/RMSE khớp log. [Bằng chứng và giới hạn](../reports/BENCHMARK_FSCD147.md). Kết quả tổng thể này chưa trả lời đầy đủ câu hỏi đổi X/Y trên cùng ảnh.

## Tiến độ chi tiết

| Việc | Trạng thái ngày 20/10 | Bằng chứng / điều kiện xong |
|---|---|---|
| M0–M2: môi trường, checkpoint | Đã chạy được và audit | Inference thật; benchmark có log ops 6/6 đạt |
| M3: smoke 1 ảnh / 3 query | Đã chạy/xem ảnh | [Lịch sử trong WORKLOG](../WORKLOG.md) |
| M4–M5: B0/B2 pilot | Đã chạy đủ 5 ảnh / 15 query | [Review và bảng kết quả](../results/countgdpp/b2_remaining3_20261015/REVIEW.md) |
| M6: E1/E2 kiểm ngưỡng | Đã đóng phạm vi 2 ảnh / 6 query | E2 .35 không chạy; E3 chưa cần mở chỉ để đủ lưới |
| Review Trí / Triệu | **15/15 mỗi người về định tính** | [Review Triệu chốt v1 ngày 19/10](<../workspace Trí and Triệu/Triệu/TRIEU_VISUAL_REVIEW.md>), đọc lại 20/10; guitar/q04_2 đã làm rõ |
| **Phần 2: chấm lại pilot** | **Đã chuẩn bị; chưa có bằng chứng chạy evaluator mới** | [Hướng dẫn](PHAN_2_DANH_GIA.md); self-test PASS → output thật → kiểm ID/coverage/metric |
| **Phần 3: tổng kết pilot** | **Bản nháp, chờ phần 2 và nhóm duyệt** | [Hướng dẫn](PHAN_3_TONG_KET.md); sửa [PILOT_SUMMARY](../reports/PILOT_SUMMARY.md) |
| Benchmark FSCD-147 theo cấu hình paper | **Đã chạy đủ; count metrics đã kiểm** | Run `full_20261015T080230Z`, audit 20/10; MAE=8.336975, RMSE=24.637626; chưa xác nhận AP/AP50 |
| P4: chọn một can thiệp | Chưa chốt | Một lỗi, một giả thuyết, một ứng viên và cách đo |
| P5: đánh giá cải tiến/holdout/báo cáo | Chưa làm | Khóa cấu hình, đánh giá tập riêng, báo kết quả và giới hạn |

Trạng thái “chưa có bằng chứng” được xác định từ file đang có; nếu bạn chạy ở máy khác thì nhập output/log để kiểm. Có code không có nghĩa đã chạy đạt.

## Phần 2 và phần 3 lần trước nghĩa là gì?

**Phần 2 = kiểm số liệu pilot bằng evaluator.** Đọc các dự đoán B0/B2 đã lưu, ghép đúng 15 ID với nhãn thật, tính MAE/RMSE và kiểm nhãn q05_2. Dùng CPU; không cần rerun model. Khác với **E2**, vốn là thí nghiệm đổi ngưỡng chọn mẫu đã làm trước đó.

**Phần 3 = chốt bản tổng kết pilot.** Ghi số liệu đã xác nhận, ví dụ lỗi, điều còn chưa chắc và câu hỏi sẽ thử tiếp. Phần này sửa Markdown, không có lệnh train. Khác với **E3**, vốn là lưới hai ngưỡng chưa cần chạy.

## Điều kiện đóng vòng pilot hiện tại

- [ ] Phần 2: self-test chạy PASS; có output cho 15 query/5 ảnh, coverage và metric hợp lệ; nhãn q05_2 cho 14 khung = 4 vật mục tiêu + 1 khung trùng + 9 sai loại.
- [x] Review định tính đã đủ: bản Triệu chốt 15/15, guitar được xác nhận đúng theo quy ước review, q04_2 final giải thích đủ 32 khung. Không đồng nhất review này với annotation định vị chính thức hoặc xác minh độc lập mọi GT.
- [ ] Phần 3: PILOT_SUMMARY có run thực tế, người/ngày kiểm, giới hạn và quyết định chuyển bước. Tách số liệu, quan sát bằng mắt và giả thuyết.

Đóng vòng nhỏ này chưa thay cho phần mở rộng dữ liệu: dự kiến 20–30 ảnh dev, xác minh nguồn/nhãn, có truy vấn vắng mặt chắc chắn và tập holdout theo ảnh gốc. Chốt phạm vi vừa sức cùng Triệu trước khi thực thi. Chỉ số định vị cần nhãn phù hợp và quy tắc matching, không suy ra từ count.

## Điều đã học được

Trên cùng 15 query: B0 MAE=19.4, RMSE≈24.316; B2 MAE=22.0, RMSE≈30.091; exact count 1/15 cả hai. B2 giảm sai số 6, tăng 4, giữ nguyên 5 query. Các số đã có trong [kết quả cũ](../results/countgdpp/b2_remaining3_20261015/combined_first5_metrics.json), còn chờ evaluator mới đối chiếu.

Plates/rulers/raspberries có mẫu đúng loại 3/3 nhưng final vẫn sai/thừa. Blackberries có hiện tượng đếm phần quả. Những quan sát này hỗ trợ ưu tiên lỗi đếm nhầm loại, chưa chứng minh nguyên nhân nội tại hoặc khái quát ra mọi cấu hình CountGD++.

## Bước sau khi chốt pilot

Trí và Triệu chọn **một** giả thuyết giúp giảm khung sai loại mà giữ được vật đúng; chọn cấu hình nền áp dụng cải tiến và giữ nguyên đối chứng. Nếu cải tiến trên B2 thì kết luận giới hạn ở B2; muốn kết luận cho cấu hình paper phải kiểm cấu hình đó trên cùng dữ liệu/câu hỏi liên quan. MAE tổng thể trên FSCD-147 không thay phép đo X/Y.

Xác định phép đo, nhãn, dev/holdout trước khi chạy. Không train hay mở thêm model chỉ để có thêm việc. Khi chọn được phương pháp mới cập nhật kế hoạch thực thi, không xem lựa chọn còn bỏ trống là kết quả đã làm.

## Cách ghi tiến độ

Mỗi buổi thêm một mục ở [WORKLOG](../WORKLOG.md). Khi có mốc được kiểm, sửa dòng trạng thái ở đây và bước tiếp ở [HANDOFF](../HANDOFF/HANDOFF.md). Không tạo thêm handoff theo ngày tại thư mục hiện hành. Các bản cũ chỉ để tra cứu trong [quá khứ](<../quá khứ/README.md>).

[Protocol kỹ thuật](PIPELINE_COUNTGDPP.md) · [Phân công/schema](PIPELINE_PHAN_CONG.md). Mã M0–M6/E1–E3/P4–P5 được giữ để tra log cũ; dùng bốn chặng ở đầu trang khi báo cáo tiến độ.
