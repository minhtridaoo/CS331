# P4 - Independent Object Annotation Review

Reviewer: Trieu
Image: mcac_200.jpg
Status: Independent review before comparing assistant labels

## Task

Review all numbered bounding boxes independently.

Queries:
- q03_1: pens (but muc)
- q03_2: rulers (thuoc ke)
- q03_3: pencils (but chi)

For each query, open:
- overview_numbered.jpg
- crops_numbered.jpg
- annotation_template.csv

Fill the CSV columns:

rank:
  Keep the original box number.

visual_class:
  pen, pencil, ruler, or unknown.

is_target:
  true if the box contains the requested object type.
  false otherwise.
  If uncertain, leave blank and explain in notes.

visual_object_id:
  Give each physical object a unique ID within the query.
  Use the same ID if multiple boxes cover the same object.

duplicate_of_rank:
  If a box repeats an earlier physical object,
  record that earlier rank. Otherwise leave blank.

reviewed_by:
  Trieu

notes:
  Explain uncertain, mixed, truncated, or duplicate boxes.

## Important

- Review every box independently.
- Do not consult assistant preliminary annotations first.
- Do not change rank numbers or bounding boxes.
- Report disagreements and uncertain labels explicitly.
- After completion, return all three filled CSV files.
- These annotations are not yet an official benchmark.
